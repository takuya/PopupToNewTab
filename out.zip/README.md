= About 

Chrome Extension: PopUpToNewTab

This Extension disables POPUP.Instead of PopUp, Open in NewTab

== What is 

Some WebSite open Windows by window.open(). These Pop ups is able to open New Window, Beause these are triggered by click.These Popups make us mad.
So we need to make window.open not to open new window but to open a new tab.



